export const books = {
  home: '/',
  cart: 'cart',
  pizzaItems: 'pizza/:id',
  error: '*'
}